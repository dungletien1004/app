import { Component } from '@angular/core';

@Component({
  selector: 'app-home-shop',
  templateUrl: './home-shop.component.html',
  styleUrls: ['./home-shop.component.scss'],
})
export class HomeShopComponent {
 
}
